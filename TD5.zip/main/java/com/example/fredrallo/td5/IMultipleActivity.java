package com.example.fredrallo.td5;

/**
 * Created by fred on 11/03/2018.
 */

interface IMultipleActivity {
    String POSITION = "position";
}
