package com.example.fredrallo.td5;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import java.util.ArrayList;

/**
 * Created by F. Rallo on 11/03/2018.
 */
public class MatiereActivity extends AppCompatActivity implements IMultipleActivity{

    @Override

    public void onCreate(Bundle savedInstanceState) {
        Log.d("MATIEREACTIVITY", "start");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mat_layout);
        //récupération des extras //TODO assurer que getExtra ne retourne pas null
        int pos = Integer.parseInt(getIntent().getExtras().get(POSITION).toString());

        Log.d("MATIEREACTIVITY"," pos="+pos);
        //récupération des éléments pour affichage
        ListView maListView = findViewById(R.id.listView2);

        ArrayList<String> maListeDeNomsDeMatiere = new ArrayList<String>();
        for(int i=0 ; i<ListeDeDiplomes.getInstance().get(pos).getMatieres().size() ; i++) {
            maListeDeNomsDeMatiere.add(ListeDeDiplomes.getInstance().get(pos).getMatieres().get(i).toString());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this,
                android.R.layout.simple_list_item_1,
                maListeDeNomsDeMatiere );
        maListView.setAdapter(adapter);
    }
}
