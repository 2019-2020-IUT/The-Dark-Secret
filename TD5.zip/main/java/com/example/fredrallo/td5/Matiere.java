package com.example.fredrallo.td5;
import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by F. Rallo on 11/03/2018.
 */
public class Matiere {
    private int coef;
    private String nom;

    public Matiere(String nom, int coef){
        this.nom = nom;
        this.coef = coef;
    }

    public Matiere(){}

    public int getCoef() {
        return coef;
    }

    public void setCoef(int coef) {
        this.coef = coef;
    }


    @Override
    public String toString() {
        return   nom + "  coef=" + coef +" ";
    }


}
