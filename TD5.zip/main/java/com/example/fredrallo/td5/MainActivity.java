package com.example.fredrallo.td5;

        import android.content.Intent;
        import android.os.Bundle;
        import android.support.v7.app.AppCompatActivity;
        import android.widget.*;


public class MainActivity extends AppCompatActivity implements IDiplomeAdapterListener, IMultipleActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Récupération de la liste des diplomes
        ListeDeDiplomes.getInstance().construireListe(this);

        //Création et initialisation de l'Adapter pour les diplomes
        DiplomeAdapter adapter = new DiplomeAdapter(this,  ListeDeDiplomes.getInstance() );

        //Récupération du composant ListView
        ListView monListView = findViewById(R.id.listView);

        //Initialisation de la liste avec les données
        monListView.setAdapter(adapter);

        //Ecoute des évènements sur la liste
        adapter.ajouterUnEcouteur(this);
    }


    @Override
    public void onClickNom(int position) {
        Intent intent = new Intent(MainActivity.this,MatiereActivity.class);
        intent.putExtra(POSITION, position);
        startActivity(intent);
    }
}
