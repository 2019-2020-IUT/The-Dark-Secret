package com.example.fredrallo.td5;

import android.content.Context;
import android.graphics.Color;
import android.support.constraint.ConstraintLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;


/**
 * Modify by F. Rallo on 11/02/2018.
 */
public class DiplomeAdapter extends BaseAdapter {
    private ListeDeDiplomes maListeDeDiplomes;
    private LayoutInflater mInflater; //Un mécanisme pour gérer l'affichage graphique depuis un layout XML
    private IDiplomeAdapterListener ecouteur;

    /**
     * Constructeur normal
     * @param context le contexte de l'activité
     * @param uneListeDeDiplomes la liste que l'on doit adapter
     */
    public DiplomeAdapter(Context context, ListeDeDiplomes uneListeDeDiplomes) {
        maListeDeDiplomes = uneListeDeDiplomes;
        mInflater = LayoutInflater.from(context);
    }

    /**
     * surcharge obligatoire de BaseAdapter
     * @return nb de diplome à adapter
     */
    public int getCount() {
        return maListeDeDiplomes.size();
    }

    /**
     * surcharge obligatoire de BaseAdapter
     */
    public Object getItem(int position) {
        return maListeDeDiplomes.get(position);
    }

    /**
     * surcharge obligatoire de BaseAdapter
     */
    public long getItemId(int position) {
        return position;
    }


//--------------------------------------------------------------


    public View getView(int position, View convertView, ViewGroup parent) {
        ConstraintLayout layoutItem;

        //(1) : Réutilisation des layouts
        if (convertView == null) {
            //Initialisation de notre item à partir du  layout XML ""
            layoutItem = (ConstraintLayout) mInflater.inflate(R.layout.diplome_layout, parent, false);
        } else {
            layoutItem = (ConstraintLayout) convertView;
        }

        //(2) : Récupération des TextView de notre layout
        TextView tvNomDuResponsable = layoutItem.findViewById(R.id.textResp);
        TextView tvNomDuDiplome = layoutItem.findViewById(R.id.textDip);
        TextView tvDureeDuDiplome = layoutItem.findViewById(R.id.textDuree);
        ImageView imageDuDiplome = layoutItem.findViewById(R.id.imageView);

        //(3) : Renseignement des valeurs
        tvNomDuResponsable.setText(maListeDeDiplomes.get(position).getResponsable().getNom());
        tvNomDuDiplome.setText(maListeDeDiplomes.get(position).getNom());
        tvDureeDuDiplome.setText(Integer.toString(maListeDeDiplomes.get(position).getDuree()));
        imageDuDiplome.setImageResource(maListeDeDiplomes.get(position).getResponsable().getPhoto());

        //(4) Changement de la couleur du fond de notre item
        if (maListeDeDiplomes.get(position).getDuree() >= 3)
            tvDureeDuDiplome.setTextColor(Color.RED);

        tvNomDuResponsable.setTag(position);
        tvDureeDuDiplome.setTag(position);
        tvNomDuDiplome.setTag(position);

        //placer un écouteur sur le nom de diplome
        tvNomDuDiplome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer position = (Integer)v.getTag();
                //TODO vérifier si unécouteur==null ou si maListeDeDiplome==null
                ecouteur.onClickNom(position);
            }
        });
        //On retourne l'item créé.
        return layoutItem;
    }





    /**
     * rajoute un élément à écouter
     * appellée par MainActivity
     * @param elementAEcouter est un élément à écouter
     */
    public void ajouterUnEcouteur(IDiplomeAdapterListener elementAEcouter) {
        ecouteur = elementAEcouter;
    }
}


