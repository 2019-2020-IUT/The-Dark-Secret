package com.example.fredrallo.td5;


/**
 * Created by F. Rallo on 11/03/2018.
 */
public class Personne {

    private String nom;
    private int photo;
    private String remarques;

    /**
     * constructeur par défaut
     */
    public Personne(){}

    /**
     * constructeur normal
     * @param nom de la personne
     * @param photo est le num de la photo dans la classe R
     * @param remarques est le texte associé à cette personne
     */
    public Personne(String nom, int photo,String remarques) {
        this.nom = nom;
        this.photo=photo;
        this.remarques=remarques;
    }

    //------------ accesseurs -----------
    public String getNom() {
        return nom;
    }
    public int getPhoto() {
        return photo;
    }
    public String getRemarques() {
        return remarques;
    }


    @Override
    public String toString(){
        return "nom='" + nom + "' , remarques=" + remarques  ;
    }
}
