package com.example.fredrallo.td5;

import android.content.Context;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * ListeDeDiplomes est un singleton
 * TODO ne gère pas le multi - threading
 *
 * Created by F. Rallo on 11/03/2018.
 */
public final class ListeDeDiplomes {
    private static final String FICHIER_JSON = "Diplomes.json";
    private List<Diplome> maListeDeDiplomes;
    private static volatile ListeDeDiplomes monInstance = null;

    /**
     * constructeur PRIVE ==> singleton
     */
    private ListeDeDiplomes(){
        Log.d("LISTEDEDIPLOMES","initialisé");
        maListeDeDiplomes = new ArrayList<Diplome>();
    }

    public int size(){
        return maListeDeDiplomes.size();
    }

    public Diplome get(int pos){
        System.out.println("ListeDeDiplome.get("+ pos +") ="+maListeDeDiplomes.get(pos));
        return maListeDeDiplomes.get(pos);
    }


    /**
     * mécanisme classique de singleton
     * @return une instance unique
     */
    public static ListeDeDiplomes getInstance() {
        if (monInstance == null)
            monInstance = new ListeDeDiplomes();
        return monInstance;
    }

    /**
     * Création de la liste des diplomes
     * @param context
     */
    public void construireListe(Context context){
        try {// Récupération du json

            JSONArray jsonArray = new JSONArray(getJSONFromAsset(context));

            // Récupération des diplomes
            for(int i = 0; i < jsonArray.length(); i++) {
                maListeDeDiplomes.add(getDiplomeFromJSONObject(jsonArray.getJSONObject(i),context));
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    /**
     * fabrique un Diplome à partir d'un élément JSON
     * @param jsonObject
     * @param context
     * @return un nouveua Diplome
     * @throws JSONException lorsque le JSON n'est pas conforme aux attentes
     */
    private  Diplome getDiplomeFromJSONObject(JSONObject jsonObject,Context context) throws JSONException { // static
        String nom;
        int duree;
        String nomResponsable;
        int photo;
        String remarque;
        Personne responsable;

        nom = jsonObject.getString("nom");
        duree = jsonObject.getInt("duree");

        //responsable
        nomResponsable=jsonObject.getJSONObject("responsable").getString("nom");
        remarque=jsonObject.getJSONObject("responsable").getString("remarque");
        photo = context.getResources().getIdentifier(
                jsonObject.getJSONObject("responsable").getString("photo") ,
                "mipmap",
                context.getPackageName()    );

        responsable = new Personne(nomResponsable,photo,remarque);

        // matieres
        ArrayList<Matiere> maListeDeMatiere = new ArrayList<>();
        for(int i = 0; i < jsonObject.getJSONArray("matieres").length(); i++) {
            Matiere matiere = new Matiere(
                    jsonObject.getJSONArray("matieres").getJSONObject(i).getString("nom"),
                    jsonObject.getJSONArray("matieres").getJSONObject(i).getInt("coef"));

            maListeDeMatiere.add(matiere);
        }
        return new Diplome(nom, duree,responsable ,maListeDeMatiere);
    }




    /**
     * Lire le fichier Json dans une string
     * @param context
     * @return
     */
    private  String getJSONFromAsset(Context context) { //static
        String json = null;
        try {
            InputStream is = context.getAssets().open(FICHIER_JSON);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }


    @Override
    public String toString() {
        String res;
        res = "ListeDeDiplomes= { ";
        for (Diplome unDiplome : maListeDeDiplomes) {
            res += unDiplome+"";
        }
        res += "maListeDeDiplomes=" + maListeDeDiplomes ;
        res +=" }";
        return res;
    }
}

