package com.example.fredrallo.td5;


import java.util.ArrayList;

public class Diplome {
    private String nom;
    private int duree;
    private Personne responsable;
    public ArrayList<Matiere> maListeDeMatiere;

    /**
     * constructeur par défaut
     */
    public Diplome(){}

    /**
     * constructeur normal
     * @param nom du diplome
     * @param duree en année pour obtenir le diplome
     * @param responsable du diplome à obtenir
     * @param matieres liste de matières pour ce diplome
     */
    public Diplome(String nom, int duree, Personne responsable,ArrayList<Matiere> matieres) {
        this.nom = nom;
        this.duree = duree;
        this.responsable = responsable;
        this.maListeDeMatiere=matieres;

    }

    // ---------------------- accesseurs -------------------------
    public String getNom() {
        return nom;
    }

    public ArrayList<Matiere> getMatieres(){return maListeDeMatiere;}

    public int getDuree() {
        return duree;
    }

    public Personne getResponsable() {
        return responsable;
    }


    @Override
    public String toString() {
        return "Diplome{" +
                "nom='" + nom + '\'' +
                ", duree=" + duree +
                ", responsable='" + responsable.getNom() + '\'' +
                '}';
    }
}
