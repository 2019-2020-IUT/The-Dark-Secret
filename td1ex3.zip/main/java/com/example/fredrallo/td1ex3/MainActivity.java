package com.example.fredrallo.td1ex3;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
    private int compteur = 0;
    private int somme = 0;

    @Override
    	/**
         * Cette méthode est appelée automatiquement par le système
         * --> lorsqu'il s'agit d'une nouvelle activité
         * --> A chaque fois que la vue de l'activité est raffraichie
         *     y compris après une rotation du tel,
		 *
		**/
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button bMoinsUn = findViewById(R.id.bMoinsUn);
        Button bPlusUn = findViewById(R.id.bPlusUn);
        final TextView tvCompteur = findViewById(R.id.tvCompteur);
        final TextView tvsomme = findViewById(R.id.tvsomme);

        tvCompteur.setText(Integer.toString(compteur) + "");
        tvsomme.setText(Integer.toString(somme) + "");


        if (savedInstanceState != null) {
            compteur = savedInstanceState.getInt("compteur");
        }


        bPlusUn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                compteur++;
                somme += compteur;
                tvCompteur.setText(Integer.toString(compteur) + "");
                tvsomme.setText(Integer.toString(somme) + "");
            }
        });

        bMoinsUn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                compteur--;
                somme -= compteur;
                tvCompteur.setText(Integer.toString(compteur)+"");
                tvsomme.setText(Integer.toString(somme) + "");
            }
        });
    }






    @Override
    protected void onSaveInstanceState(Bundle outState) {
		/*
		 * On sauvegarde la valeur du compteur, qui servira si l'activité actualisée dans onCreate()
		 */
        outState.putInt("compteur", compteur);
        super.onSaveInstanceState(outState);
    }

}
