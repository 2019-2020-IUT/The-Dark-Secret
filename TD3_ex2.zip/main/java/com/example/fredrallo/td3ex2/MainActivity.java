package com.example.fredrallo.td3ex2;
import android.app.Activity;
import android.app.AlertDialog;

import android.os.Bundle;
import android.widget.*;

/**
 * Modify by F. Rallo on 11/02/2018.
 */
public class MainActivity extends Activity implements IDiplomeAdapterListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Récupération de la liste des diplomes
        ListeDeDiplomes uneListeDeDiplomes = new ListeDeDiplomes();
        uneListeDeDiplomes.construireListe();

        //Création et initialisation de l'Adapter pour les diplomes
        DiplomeAdapter adapter = new DiplomeAdapter(this, uneListeDeDiplomes);

        //Récupération du composant ListView
        ListView list = (ListView)findViewById(R.id.listView);

        //Initialisation de la liste avec les données
        list.setAdapter(adapter);

        //Ecoute des évènements sur l'adapter
        adapter.addListener(this);

    }


    /**
     * on a cliqué su l'un des éléments de l'activité
     * @param item l'élément qui a été cliqué
     */
    public void onClickNom(Diplome item) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Diplome");
        builder.setMessage("Vous avez cliqué sur : " + item.getNom());
        builder.setPositiveButton("Oui", null);
        builder.setNegativeButton("Non", null);
        builder.show();
    }







}
