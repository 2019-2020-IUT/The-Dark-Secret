package com.example.fredrallo.td3ex2;

import com.example.fredrallo.td3ex2.Diplome;

/**
 * Modify by F. Rallo on 11/02/2018.
 * Interface pour écouter les évènements sur le nom du diplome
 */
public interface IDiplomeAdapterListener {
    public void onClickNom(Diplome item);
}
