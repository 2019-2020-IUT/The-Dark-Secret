package com.example.fredrallo.td3ex2;

/**
 * Modify by F. Rallo on 11/02/2018.
 */
public class Diplome {
    private String nom;
    private int duree;
    private Personne responsable;


    /**
     * constructeur par défaut : jamais utilisé à priori
     */
    public Diplome(){this("",-1, null);}


    /**
     * constructeur normal
     * @param nom de la Personne
     * @param duree durée pour passer le diplome
     * @param chefDepartement est le responsable du diplome
     */
    public Diplome(String nom, int duree, Personne chefDepartement) {
        this.nom = nom;
        this.duree = duree;
        this.responsable = chefDepartement;
    }


    public String getNom() {
        return nom;
    }

    public int getDuree() {
        return duree;
    }

    public Personne getResponsable() {
        return responsable;
    }



    @Override
    public String toString() {
        return "Diplome{ nom='" + nom + "\'" +
                " , duree=" + duree +
                " , responsable='" + responsable.getNom() + "\' )";
    }
}
