package com.example.fredrallo.td3ex2;
import java.util.ArrayList;

/**
 * Modify by F. Rallo on 11/02/2018.
 */
public class ListeDeDiplomes {

    ArrayList<Diplome> liste;

    public ListeDeDiplomes(){
        liste = new ArrayList<Diplome>();
    }

    public int size(){
        return liste.size();
    }

    public Diplome get(int pos){
        return liste.get(pos);
    }

    public void construireListe(){
        liste.add(new Diplome("LICENCE LPSIL", 3, new Personne("amidala", R.mipmap.amidala,"blabla pour Amidala ")));
        liste.add(new Diplome("DUT GEA", 2, new Personne("blue", R.mipmap.blue,"blabla pour Blue ")));
        liste.add(new Diplome("DUT GEII", 2, new Personne("calrissian", R.mipmap.calrissian,"blabla pour Calrissian ")));
        liste.add(new Diplome("LICENCE LPDAM", 3,new Personne("c3po", R.mipmap.c3po,"Droïde protocolaire de série 3PO en armature dorée  ")));
        liste.add(new Diplome("DUT INFORMATIQUE",2, new Personne("Vador", R.mipmap.vador,"blabla pour Vador ")));
    }


}

