package com.example.fredrallo.td4ex2;


import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by F. Rallo on 01/02/2018.
 */
public class Personne implements Parcelable {

    private String nom;
    private int photo;
    private String remarques;

    public Personne(String nom, int photo,String commentaire) {
        this.nom = nom;
        this.photo = photo;
        this.remarques = commentaire;

    }

    public Personne(){}

    public String getNom() {
        return nom;
    }
    public void setNom(String nom) {
        this.nom = nom;
    }


    public int getPhoto() {
        return photo;
    }
    public void setPhoto(int nom) {
        this.photo = photo;
    }


    public String getRemarques() {
        return remarques;
    }
    public void setRemarques(String commentaire) {
        this.remarques = commentaire;
    }

 @Override
    public String toString(){
        return
                "nom='" + nom + "'  , remarques=" + remarques  ;
    }



    //-------------- pour Parcelable -----------------------------

        public Personne(Parcel in) {
            this.nom = in.readString();
            this.photo= in.readInt();
            this.remarques = in.readString();
        }

        @Override
        public int describeContents()
        {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags)
        {
            dest.writeString(nom);
            dest.writeInt(photo);
            dest.writeString(remarques);
        }

        public static final Parcelable.Creator<Personne> CREATOR = new Parcelable.Creator<Personne>()
        {
            @Override
            public Personne createFromParcel(Parcel source)
            {
                return new Personne(source);
            }

            @Override
            public Personne[] newArray(int size)
            {
                return new Personne[size];
            }
        };


        public static Parcelable.Creator<Personne> getCreator()
        {
            return CREATOR;
        }
    }


