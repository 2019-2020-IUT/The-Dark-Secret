package com.example.fredrallo.td4ex2;

import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import android.support.v7.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements IPersonnesMultipleActivites{
    private listeDePersonnes maListe= new listeDePersonnes();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView laListView =  findViewById(R.id.listeView);

        maListe.construireListe();
        afficherLaListeDePersonnage( laListView );
        addListernerListe( laListView );
    }


    public void afficherLaListeDePersonnage(  ListView uneLisView ) {
        ArrayList<Personne> listeDePersonnes= maListe.getMaListeDePersonnes();
        ArrayList<String> listeDeNoms= new ArrayList<String>();
        for(int i=0;i<listeDePersonnes.size();i++)
            listeDeNoms.add(((maListe.getPers(i)).getNom()));
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, listeDeNoms);
        uneLisView.setAdapter(dataAdapter);
    }



    public void addListernerListe( ListView uneLisView ) {

        uneLisView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Personne user = maListe.getPers(position);
                Intent intent = new Intent(MainActivity.this, ResultActivity.class);
                intent.putExtra(USER, user);
                startActivity(intent);
            }


            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(MainActivity.this, "Vous n'avez rien sélectionné", Toast.LENGTH_SHORT).show();
            }
        });
    }


}

