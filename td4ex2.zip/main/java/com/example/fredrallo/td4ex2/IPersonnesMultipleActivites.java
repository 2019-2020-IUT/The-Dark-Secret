package com.example.fredrallo.td4ex2;

/**
 * Created by fred on 04/03/2018.
 */

interface IPersonnesMultipleActivites {
    final String USER = "user";
}
