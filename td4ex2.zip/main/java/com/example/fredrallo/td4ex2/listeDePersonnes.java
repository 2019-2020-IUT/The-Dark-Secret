package com.example.fredrallo.td4ex2;

import java.util.ArrayList;


public class listeDePersonnes {

    private ArrayList<Personne> maListeDePersonnes;

    public listeDePersonnes(){
        maListeDePersonnes = new ArrayList<Personne>();
    }

    public int size(){
        return maListeDePersonnes.size();
    }

    public Personne getPers(int pos){
        return maListeDePersonnes.get(pos);
    }

    public ArrayList<Personne> getMaListeDePersonnes(){
        return maListeDePersonnes;
    }

    public ArrayList<Personne> setList(){
        return maListeDePersonnes;
    }


    public void construireListe(){
        maListeDePersonnes.add(new Personne("amidala", R.mipmap.amidala,"blabla pour Amidala "));
        maListeDePersonnes.add(new Personne("blue", R.mipmap.blue,"blabla pour Blue "));
        maListeDePersonnes.add(new Personne("c3po", R.mipmap.c3po,"Droïde protocolaire de série 3PO en armature dorée  "));
        maListeDePersonnes.add(new Personne("calrissian", R.mipmap.calrissian,"blabla pour Calrissian "));
        maListeDePersonnes.add(new Personne("chewbacca", R.mipmap.calrissian,"blabla pour chewbacca"));
        maListeDePersonnes.add(new Personne("daragon", R.mipmap.calrissian,"blabla pour daragon "));
    }

}
