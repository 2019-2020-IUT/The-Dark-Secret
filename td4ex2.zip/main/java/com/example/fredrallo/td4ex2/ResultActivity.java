package com.example.fredrallo.td4ex2;

/**
 * Created by F. Rallo on 10/02/2015.
 */
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

public class ResultActivity extends AppCompatActivity implements IPersonnesMultipleActivites{
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_affichage);

        //récupération des éléments du layout
        TextView tvNom = findViewById(R.id.nomPersonne);
        ImageView ivPhoto= findViewById(R.id.imagePersonne);

        //récupération des éléments de l'activité appelante
        Personne user = getIntent().getExtras().getParcelable(USER);

        //affichage
        tvNom.setText("Personnage  : "   + user.getNom()+ " \n " + user.getRemarques() );
        ivPhoto.setImageResource(user.getPhoto());

    }
}
