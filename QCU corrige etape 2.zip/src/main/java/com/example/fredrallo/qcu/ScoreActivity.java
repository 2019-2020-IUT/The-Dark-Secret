package com.example.fredrallo.qcu;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.TreeMap;

/**
 * TODO : faire en sorte de gérer les ex-eco
 */
public class ScoreActivity extends AppCompatActivity  implements IActivite {
    static TreeMap<Integer, String> map = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        int score;
        String nom;
        TextView tvScore;
        TextView tvNom;
        Button b;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);
        Intent monIntent = getIntent();

        if (map==null)
            map = new TreeMap( new Hashtable<Integer,String>() );

        tvScore = findViewById(R.id.score);
        tvNom = findViewById(R.id.nom);
        b = findViewById(R.id.ok);

        if (monIntent != null) {
            nom =  monIntent.getStringExtra(NOM_JOUEUR);
            score = Integer.parseInt(monIntent.getStringExtra(SCORE));

            tvNom.setText("Bravo " + nom);
            tvScore.setText("Votre score est de " + score);
            majRecord(nom,score);
        }

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent monIntent = new Intent(ScoreActivity.this, MainActivity.class);
                startActivity(monIntent);
            }
        });

    }

    private void majRecord(String nom, int score){
        map.put(score,nom);
        //map.put(-2,"deuz");
        //map.put(-6,"troiz");

        //TODO modifier max
        afficherRecords();
    }


    private void afficherRecords(){

        TextView tvRecord1 = findViewById(R.id.record1);
        TextView tvRecord2 = findViewById(R.id.record2);
        TextView tvRecord3 = findViewById(R.id.record3);
        TextView[] tvRecord = {tvRecord1,tvRecord2, tvRecord3};
        int i=2;
        Iterator<Integer> keySetIterator = map.keySet().iterator();
        while(keySetIterator.hasNext()){
            Integer key = keySetIterator.next();
            if (key>=0) tvRecord[i].setText(map.get(key)+" : " + key);
            i--;
        }



        //TODO
        //System.out.println("RECORD : "+ record1+" , "+record2+" , "+record3);
    }

}