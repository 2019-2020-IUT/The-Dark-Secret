package com.example.fredrallo.qcu;


        import android.content.Context;
        import android.content.Intent;
        import android.content.SharedPreferences;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.View;
        import android.view.animation.Animation;
        import android.view.animation.AnimationUtils;
        import android.widget.Button;
        import android.widget.CheckBox;
        import android.widget.TextView;
        import java.util.ArrayList;


/**
 * Affiche des questions sucéssivement et demande une réponse à l'utilisateur
 * Les questions sont traitées lorsqu'on clique sur le bouton (un score est calculé)
 */
public class GameActivity extends AppCompatActivity implements IActivite {
    private static final String NUM_QUESTION = "numQuestion" ;

    private boolean estPossibleDeContinuer = true; //false lorsque la partie est finie
    private int score = 0;  //score en cours d'utilisation
    private Question maQuestion; //Question courante
    private int numQuestionCourante = 1; //rang de la Question courrante dans la liste
    private ArrayList<Question> maListeDeQuestions; //une liste de Questions à afficher
    private String nomJoueur;


    @Override
    protected void onStart() {
        super.onStart();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        // récupère les élément graphiques
        final TextView tvNumQuestion = findViewById(R.id.numQuestion);
        final TextView tvTxtQuestion = findViewById(R.id.txtQuestion);
        Button b = findViewById(R.id.button);
        final TextView tvScore = findViewById(R.id.score);
        final CheckBox checkboxReponseA =findViewById(R.id.checkBoxA);
        final CheckBox checkboxReponseB =findViewById(R.id.checkBoxB);
        final CheckBox checkboxReponseC =findViewById(R.id.checkBoxC);
        final CheckBox checkboxReponseD =findViewById(R.id.checkBoxD);
        TextView tvPropositionA = findViewById(R.id.prop1);
        TextView tvPropositionB = findViewById(R.id.prop2);
        TextView tvPropositionC = findViewById(R.id.prop3);
        TextView tvPropositionD = findViewById(R.id.prop4);
        final CheckBox tabCheckboxReponses[] = {checkboxReponseA, checkboxReponseB, checkboxReponseC, checkboxReponseD};
        final TextView tabTvProposition[] = {tvPropositionA, tvPropositionB, tvPropositionC, tvPropositionD};


        // Récupération de la valeur sauvegardée (score et numQuestionCourante)
        Intent monIntent = getIntent();
        if (monIntent != null) {
            nomJoueur = monIntent.getStringExtra(NOM_JOUEUR);
        }
        SharedPreferences preferences = getPreferences(Context.MODE_PRIVATE);
        score = preferences.getInt(SCORE, 0);
        numQuestionCourante =  preferences.getInt(NUM_QUESTION, 1);


        //récupérer le 1er élément d'un nouvelle listeDeQuestion
        String themeChoisi = getIntent().getExtras().getString(IActivite.NOM_ACTIVITE);
        System.out.println("GAMEACTIVITY --> theme=: "+ themeChoisi);
        maListeDeQuestions = ListeDeQuestions.getMaListeDeQuestions();
        maQuestion = maListeDeQuestions.get(numQuestionCourante-1);


        //afficher le score et le nb de questions
        tvScore.setText("score : "+score);
        tvNumQuestion.setText(numQuestionCourante+"/"+maListeDeQuestions.size());

        //remplir les éléments graphiques avec la question récupérée
        afficherQuestion(maQuestion, tvTxtQuestion, tabCheckboxReponses, tabTvProposition);

        //écouter si on appuie sur le bouton
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (estPossibleDeContinuer) {
                    // si une et une seule réponse  ==> MAJScore
                    int reponseJoueur = (checkboxReponseA.isChecked() ^ checkboxReponseB.isChecked() ^ checkboxReponseC.isChecked() ^ checkboxReponseD.isChecked() ? 1 : 0);

                    if (reponseJoueur == 1) {
                        //jouer une animation sur la bonne réponse
                        Animation monAnim = AnimationUtils.loadAnimation(GameActivity.this, R.anim.agrandissement);
                        tabTvProposition[ maQuestion. getNumBonneReponse()-1 ].startAnimation(monAnim);

                        monAnim.setAnimationListener(new Animation.AnimationListener() {

                            @Override
                            public void onAnimationStart(Animation animation) {

                            }

                            @Override
                            public void onAnimationEnd(Animation animation) {
                                miseAJourScore(maQuestion, tabCheckboxReponses);    //vérifier la bonne réponse
                                tvScore.setText("score : "+score);
                                if (numQuestionCourante < maListeDeQuestions.size()) {
                                    numQuestionCourante++; //changer de question
                                    maQuestion = maListeDeQuestions.get(numQuestionCourante - 1);
                                    tvNumQuestion.setText( numQuestionCourante + "/" + maListeDeQuestions.size() );
                                    afficherQuestion(maQuestion, tvTxtQuestion, tabCheckboxReponses, tabTvProposition);
                                } else
                                    finDeLaPartie();
                            }

                            @Override
                            public void onAnimationRepeat(Animation animation) {

                            }
                        });

                    }
                }
                else finDeLaPartie();

            }
        });//end setOnClickListener

        //s'assurer au'il y a qu'un seul chexkbox de cliqué
        for (int i=0 ; i<4 ; i++ ) {
            final int numCheckboxChoisi = i;
            tabCheckboxReponses[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    for (int n=0 ; n<4 ;n++ )
                        if (n!= numCheckboxChoisi) tabCheckboxReponses[n].setChecked(false);
                }
            });
        }
    }


    /**
     * sauvegarde la valeur score et numQuestionCourante
     */
    @Override
    protected void onPause() {
        super.onPause();
        SharedPreferences preferences = getPreferences(Context.MODE_PRIVATE);
        preferences.edit()  .putInt(SCORE, score)
                            .putInt(NUM_QUESTION, numQuestionCourante)
                            .apply();
    }



    /**
     * La partie est terminée
     * ==> estPossibleDeContinuer = false;
     */
    private void finDeLaPartie() {
        Intent monIntent = new Intent(GameActivity.this, ScoreActivity.class);
        monIntent.putExtra(NOM_JOUEUR, nomJoueur);
        monIntent.putExtra(SCORE, score+"");
        score=0;
        numQuestionCourante=1;
        startActivity(monIntent);
        estPossibleDeContinuer = false;
    }




    /**
     * mettre à jour la valeur du score si besoin
     * @param uneQuestion la question courante
     * @param tabReponsesProposées les checkbox contenant la réponse proposée
     */
    private void miseAJourScore(Question uneQuestion, CheckBox[] tabReponsesProposées) {
        if (tabReponsesProposées[ uneQuestion.getNumBonneReponse()-1 ].isChecked()) {
            score++;
        }

    }


    /**
     * affiche la question dans l'activité
     * @param uneQuestion   La question courante
     * @param tvTxtQuestion le TextView qui affichera la question
     * @param tabCheckbox les checkbox des propositions de réponses
     * @param tabproposition les textView des différentes propositions
     */
    private void afficherQuestion(Question uneQuestion, TextView tvTxtQuestion, CheckBox[] tabCheckbox , TextView[] tabproposition) {
        for (int i=0 ; i<4 ; i++) {
            tabCheckbox[i].setChecked(false);
            tabproposition[i].setText(maQuestion.getTabProposition()[i]);
        }
        tvTxtQuestion.setText(uneQuestion.getTexteQuestion());

    }
}
