package com.example.fredrallo.qcu;

import java.util.ArrayList;

/**
 * Ce singleton créée une ArrayList de Questions
 * et l'initialise avec une QuestionsFactory
 * Created by fred on 14/02/2018.
 */

public abstract class ListeDeQuestions {
       private static ArrayList<Question> maListeDeQuestions = null ;




    /**
     * accesseur
     * @return ma liste de questions
     */
    public static ArrayList<Question> getMaListeDeQuestions() {
        if (maListeDeQuestions==null) {
            maListeDeQuestions = new ArrayList<Question>();
            ListeDeQuestionsFactory.creerUneListeAvecDesQuestions(maListeDeQuestions);
        }
        return maListeDeQuestions;
    }




}
