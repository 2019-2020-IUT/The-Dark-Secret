package com.example.fredrallo.qcu;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity implements IActivite{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button b = findViewById(R.id.okNom);
        final EditText nom = findViewById(R.id.nom);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent monIntent = new Intent(MainActivity.this, ThemeActivity.class);
                monIntent.putExtra(NOM_JOUEUR, nom.getText()+"");
                startActivity(monIntent);
            }
        });

        ImageView img = findViewById(R.id.imageView);
        img.setBackgroundResource(R.drawable.monanimation);
        AnimationDrawable anim= (AnimationDrawable)img.getBackground();
        anim.start();
    }


}
