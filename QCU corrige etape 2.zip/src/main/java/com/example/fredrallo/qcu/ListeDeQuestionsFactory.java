package com.example.fredrallo.qcu;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Created by fred on 22/02/2018.
 */
public abstract class ListeDeQuestionsFactory {


    /**
     * @param in : buffer with the php result
     * @param bufSize : size of the buffer
     * @return : the string corresponding to the buffer
     */
    public static String InputStreamToString (InputStream in, int bufSize) {
        final StringBuilder out = new StringBuilder();
        final byte[] buffer = new byte[bufSize];
        try {
            for (int ctr; (ctr = in.read(buffer)) != -1;) {
                out.append(new String(buffer, 0, ctr));
            }
        } catch (IOException e) {
            throw new RuntimeException("Cannot convert stream to string", e);
        }
        // On retourne la chaine contenant les donnees de l'InputStream
        return out.toString();
    }

    /**
     * @param in : buffer with the php result
     * @return : the string corresponding to the buffer
     */
    public static String InputStreamToString (InputStream in) {
        // On appelle la methode precedente avec une taille de buffer par defaut
        return InputStreamToString(in, 1024);
    }


    /**
     * Récupère une liste de personnes.
     * @return ArrayList<Personne>: ou autre type de données.
     * @author François http://www.francoiscolin.fr/
     */
    public static void creerUneListeAvecDesQuestions (ArrayList<Question> maListeDeQuestions) {
        try {
            String myurl= "http://localhost:8888/json";

            URL url = new URL(myurl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.connect();
            InputStream inputStream = connection.getInputStream();
            /*
             * InputStreamOperations est une classe complémentaire:
             * Elle contient une méthode InputStreamToString.
             */
            System.out.println("factory DEBUT plan A: " );
            String result = InputStreamToString(inputStream);

            // On récupère le JSON complet
            JSONObject jsonObject = new JSONObject(result);
            // On récupère le tableau d'objets qui nous concernent
            JSONArray array = new JSONArray(jsonObject.getString("questions"));
            // Pour tous les objets on récupère les infos
            for (int i = 0; i < array.length(); i++) {
                // On récupère un objet JSON du tableau
                JSONObject obj = new JSONObject(array.getString(i));

                // On fait le lien Personne - Objet JSON
                String titre =  obj.getString("title");
                String[] prop = new String[4];
                JSONArray jsonProp = new JSONArray(jsonObject.getString("answers"));
                // Pour toutes les propositions
                for (int j = 0; j < 4; j++) {
                    // On récupère un objet JSON du tableau
                    JSONObject uneProp = new JSONObject(jsonProp.getString(i));
                    prop[j] = uneProp.getString("answers");
                }
                int reponse =  Integer.parseInt( obj.getString("response") );
                System.out.println("factory Num : " + i);
                System.out.println("factory : " + titre);
                System.out.println("factory : " + prop[0]);
                System.out.println("factory : " + prop[1]);
                System.out.println("factory : " + prop[2]);
                System.out.println("factory : " + prop[3]);
                System.out.println("factory : " + reponse);
                maListeDeQuestions.add( new Question(   titre,
                                                        prop[0],
                                                        prop[0],
                                                        prop[0],
                                                        prop[0],
                                                        reponse )
                                      );

            }

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("factory FIN PLAN A : ");
            planB(maListeDeQuestions);
        }

    }




    public static void planB( ArrayList<Question> maListeDeQuestions){
        System.out.println("factory DEBUT PLAN B : ");


        maListeDeQuestions.add(
                new Question("Une activité c'est :",
                        "un jeu pour Android",
                        "ce qui sera afficher sur l'écran",
                        "ce que contient la mémoire",
                        "ce que je ferai demain",
                        2  )
        );
        maListeDeQuestions.add(
                new Question("Un ArrayList c'est :",
                        "n'importe quoi !",
                        "un type de tableau dynamique",
                        "une vue de profile",
                        "je ne sais pas",
                        2  )
        );
        maListeDeQuestions.add(
                new Question("Une activité c'est :",
                        "un jeu pour Android",
                        "ce que contient la mémoire",
                        "ce que je ferai demain",
                        "ce qui sera afficher sur l'écran",
                        4  )
        );
    }






    public static void creerUneListeDeThemes (ArrayList<String> maListeDeTheme) {
        maListeDeTheme.add("java");
        maListeDeTheme.add("C++");
        maListeDeTheme.add("python");
        maListeDeTheme.add("PHP");
        maListeDeTheme.add("Android");
    }
}
