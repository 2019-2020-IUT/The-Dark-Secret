package com.example.fredrallo.qcu;

import java.util.ArrayList;

/**
 * Created by fred on 22/02/2018.
 */

public interface IActivite {
    final String SCORE = "score" ;
    final String NOM_JOUEUR = "nomJoueur" ;
    final String NOM_ACTIVITE = "nomActivite";
}
