package com.example.fredrallo.qcu;


/**
 * Cette Classe décrit un objet Question contenant
 * + un libellé,
 * + 4 propositions de réponses
 * * le numéro de la bonne réponse
 */
public class Question {
    private String texteQuestion;
    private String tabProposition[];
    private int numBonneReponse;

    /**
     * constructeur par défaut
     */
    public Question(){
        this("une question ?",
                "bonne réponse",
                "mauvaise réponse",
                "mauvaise réponse",
                "mauvaise réponse",
                1);
    }


    /**
     * constructeur normal
     * Created by fred on 14/02/2018.
     */
    public Question( String texteQuestion,
                     String prop1,
                     String prop2,
                     String prop3,
                     String prop4,
                     int numOk
    ) {
        this.texteQuestion = texteQuestion;
        tabProposition = new String[4];
        tabProposition[0] = prop1;
        tabProposition[1] = prop2;
        tabProposition[2] = prop3;
        tabProposition[3] = prop4;
        numBonneReponse = numOk;
    }



    public String getTexteQuestion() {
        return texteQuestion;
    }

    public String[] getTabProposition() {
        return tabProposition;
    }

    public int getNumBonneReponse() {
        return numBonneReponse;
    }
}
