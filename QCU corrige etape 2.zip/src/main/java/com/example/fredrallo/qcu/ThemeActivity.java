package com.example.fredrallo.qcu;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class ThemeActivity extends AppCompatActivity implements IActivite {
    private static String nomJoueur;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Intent monIntent;
        final ListView maListView;
        ArrayList<String> maListeDeThemes = new ArrayList<String>();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_theme);
        maListView =  findViewById(R.id.listeView);

        // Récupération de la valeur sauvegardée (nom du joueur)
        monIntent = getIntent();
        if (monIntent != null) {
            nomJoueur = monIntent.getStringExtra(NOM_JOUEUR);
        }


        ListeDeQuestionsFactory.creerUneListeDeThemes(maListeDeThemes);
        AfficherMaListeDeThemes(maListeDeThemes, maListView);
        addListernerListeView(maListeDeThemes, maListView);
    }



    public void AfficherMaListeDeThemes(ArrayList<String> uneListeDeNoms, ListView uneListView) {
        ArrayAdapter<String> dataAdapter =
                new ArrayAdapter<String>(   this,
                        android.R.layout.simple_list_item_1,
                        uneListeDeNoms);
        uneListView.setAdapter(dataAdapter);
    }



    public void addListernerListeView(final ArrayList<String> listeDeThemes, ListView uneListView) {
        uneListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(ThemeActivity.this, GameActivity.class);
                intent.putExtra(IActivite.NOM_ACTIVITE, listeDeThemes.get(position));
                intent.putExtra(NOM_JOUEUR, nomJoueur);
                startActivity(intent);
            }


            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(ThemeActivity.this,
                        "Vous n'avez rien sélectionné",
                        Toast.LENGTH_SHORT ).show();
            }
        });
    }




}
