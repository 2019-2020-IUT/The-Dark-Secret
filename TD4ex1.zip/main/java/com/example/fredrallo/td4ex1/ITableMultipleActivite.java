package com.example.fredrallo.td4ex1;

/**
 * Created by fred on 04/03/2018.
 */

interface ITableMultipleActivite {
    final String VALEUR_TABLE = "valeur";
}
