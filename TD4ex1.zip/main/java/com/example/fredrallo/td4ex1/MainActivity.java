package com.example.fredrallo.td4ex1;


        import android.content.Intent;
        import android.os.Bundle;
        import android.support.v7.app.AppCompatActivity;
        import android.view.View;
        import android.widget.EditText;

/**
 * Created by F. Rallo on 4/03/2018.
 */
public class MainActivity extends AppCompatActivity implements  ITableMultipleActivite {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EcouterLaZoneDeSaisie();
    }




    public void EcouterLaZoneDeSaisie() {
        (findViewById(R.id.editText2)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (((EditText) (findViewById(R.id.editText2))).getText().length() != 0) {
                    int table = Integer.parseInt( ((EditText) (findViewById(R.id.editText2))).getText().toString() );
                    Intent intent = new Intent(MainActivity.this, AffichageActivity.class);
                    intent.putExtra(ITableMultipleActivite.VALEUR_TABLE, table);
                    startActivity(intent);


                }
            }
        });
    }













}
