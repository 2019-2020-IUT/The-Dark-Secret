package com.example.fredrallo.td4ex1;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import java.util.ArrayList;
import java.util.List;


public class AffichageActivity extends AppCompatActivity implements ITableMultipleActivite {
    int multiple;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ArrayAdapter<String> adapter;
        List<String> listeDeLignesAAfficher = new ArrayList<String>();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.table_mult);

        //récupération des éléments du layout (la listview)
        ListView laListView = findViewById(R.id.listView);

        //récupération des éléments de l'activité appelante
        Intent intent = getIntent();
        multiple=intent.getIntExtra(ITableMultipleActivite.VALEUR_TABLE,0);

        afficherTable(multiple, listeDeLignesAAfficher);

        //afficher les éléments de listeDeLignesAAfficher dans laListView
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listeDeLignesAAfficher);
        laListView.setAdapter(adapter);
    }



    public void afficherTable(int table,  List<String> list) {
        String chaineAffichee;
        for (int i = 1; i <= 20; i++) {
            chaineAffichee = String.valueOf(i) + " x " + String.valueOf(table) + " = " + String.valueOf( table * i );
            list.add(chaineAffichee);
        }
    }
}
