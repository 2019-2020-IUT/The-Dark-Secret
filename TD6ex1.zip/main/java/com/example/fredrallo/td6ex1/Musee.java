package com.example.fredrallo.td6ex1;

/**
 * Created by F. Rallo on 17/03/2017.
 */

public class Musee {
    private String nom;
    private String geo;

    public Musee(String nom, String geo){
        this.nom = nom;
        this.geo = geo;
    }

    public String toSTring() {
        return ""+ nom + ".\n"+ "GPS : " +geo;
    }
}