package com.example.fredrallo.td6ex1;

        import android.app.ProgressDialog;
        import android.os.AsyncTask;
        import android.os.Bundle;
        import android.support.v7.app.AppCompatActivity;
        import android.util.Log;
        import android.widget.ArrayAdapter;
        import android.widget.ListView;
        import org.json.JSONArray;
        import org.json.JSONException;
        import org.json.JSONObject;
        import java.util.*;


public class MainActivity extends AppCompatActivity {
    private final static String URL = "http://opendata.nicecotedazur.org/data/storage/f/2014-06-24T17%3A26%3A11.347Z/export-musees-galeries.json";
    private String TAG = MainActivity.class.getSimpleName();
    ProgressDialog pDialog ;
    private ListView lv;
    List<Musee> museesList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        museesList = new ArrayList<Musee>();
        lv = (ListView) findViewById(R.id.list);
        new GetMusees().execute();
    }



    /**
     * Tache asynchrone
     */
    private class GetMusees extends AsyncTask<Void,Void,Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(MainActivity.this);
            pDialog.setMessage("Connexion en cours...");
            pDialog.setCancelable(false);
            pDialog.show();
        }



        @Override

        // appeler automatiquement après onPreExecute
        protected Void doInBackground(Void... params) {
            String jsonStr;
            String nom;
            String coordonnees;
            Musee unMusee;

            for (int progress = 0; progress  < 1000000000; progress++){
                // Ne fait rien mais fait juste passer du temps
            }
            HttpHandler sh = new HttpHandler();
            jsonStr = sh.makeServiceCall(URL);

            if (jsonStr != null) {
                try {
                    JSONObject jsonObj = new JSONObject(jsonStr);
                    JSONArray musees = jsonObj.getJSONArray("docs");
                    for (int i = 0; i < musees.length(); i++) {
                        JSONObject c = musees.getJSONObject(i);
                        nom = c.getString("NOM");

                        // récupération  geometry objet
                        JSONObject geometry = c.getJSONObject("geometry");
                        coordonnees = geometry.getString("coordinates");
                        unMusee = new Musee(nom, coordonnees);
                        museesList.add(unMusee);
                    }

                } catch (final JSONException e) {
                    Log.e(TAG, "Erreur JSON " + e.getMessage());

                }
            } else {
                Log.e(TAG, "Probleme connexion ");
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            ArrayList<String> listeDeNomeDeMusees = new ArrayList<String>();

            if (pDialog.isShowing()) {
                pDialog.dismiss();
            }
            for(int i=0 ; i<museesList.size() ; i++)
                listeDeNomeDeMusees.add(museesList.get(i).toSTring());

            // UTILER UN ADAPTER PLUS JOLI!!!
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this,
                                                                        android.R.layout.simple_list_item_1,
                                                                        listeDeNomeDeMusees);
            lv.setAdapter(adapter);
        }
    }
}