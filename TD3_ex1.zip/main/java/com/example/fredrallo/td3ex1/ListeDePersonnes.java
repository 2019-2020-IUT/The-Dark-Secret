package com.example.fredrallo.td3ex1;


import java.util.ArrayList;

    /**
     * TODO: faut-il rendre cette classe abstraite ?
     */
    public class ListeDePersonnes {
        ArrayList<Personne> list;

        public ListeDePersonnes(){
            list = new ArrayList<Personne>();
        }

        public Personne getPersonne(int pos){
            return list.get(pos);
        }

        public ArrayList<Personne> getList(){
            return list;
        }

        public void construireListe(){
            list.add(new Personne("amidala", R.mipmap.amidala,"blabla pour Amidala "));
            list.add(new Personne("blue", R.mipmap.blue,"blabla pour Blue "));
            list.add(new Personne("c3po", R.mipmap.c3po,"Droïde protocolaire de série 3PO en armature dorée  "));
            list.add(new Personne("calrissian", R.mipmap.calrissian,"blabla pour Calrissian "));
        }

    }


