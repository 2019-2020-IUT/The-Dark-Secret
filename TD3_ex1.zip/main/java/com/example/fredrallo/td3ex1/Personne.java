package com.example.fredrallo.td3ex1;

/**
 * Created by F. Rallo on 11/02/2018.
 */
public class Personne {
    private String nom;
    private int photo;
    private String commentaire;


    /**
     * constructeur par défaut : jamais utilisé à priori
     */
    public Personne(){
        this("",-1,"");
    }

    /**
     * constructeur normal
     * @param nom de la Personne
     * @param photo de la Personne
     * @param txt qui servira pour le commentaire
     */
    public Personne(String nom, int photo,String txt) {
        this.nom = nom;
        this.photo=photo;
        commentaire=txt;
    }


    public String getNom() {
        return nom;
    }

    public int getPhoto() {
        return photo;
    }

    public String getCommentaire() {
        return commentaire;
    }

    @Override
    public String toString(){
        return "nom='" + nom + '\'' +", commentaire=" + commentaire  ;
    }
}
