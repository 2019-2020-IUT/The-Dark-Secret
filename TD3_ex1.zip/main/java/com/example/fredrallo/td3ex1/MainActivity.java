package com.example.fredrallo.td3ex1;

import android.os.Bundle;
import android.view.*;
import android.widget.*;
import android.support.v7.app.AppCompatActivity;
import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {
    private ListeDePersonnes maListeDePersonnes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // récupération des éléments du layout
        Spinner spinnerChoixPersonne = findViewById(R.id.spinnerPersonne);
        ImageView imageViewPhoto = findViewById(R.id.imgPersonnage);
        TextView textViewDescription= findViewById(R.id.txtPersonnage);

        //création de la liste de Personne
        maListeDePersonnes = new ListeDePersonnes();
        maListeDePersonnes.construireListe();

        //remplir le spinner (avec les éléments de maListeDePersonnes
        adapterSelon(spinnerChoixPersonne);

        //écouter si l'on veut changer de personne
        ecouteurSurSpinnerQuiChange(spinnerChoixPersonne, imageViewPhoto, textViewDescription);
    }

    /**
     * adapter un ArrayList<Personne> au contenu du layout main_activity.xml
     * @param nomDeLaPersonneChoisie est le nom d'un personne choisie depuis le spinner
    */
    public void adapterSelon(final Spinner nomDeLaPersonneChoisie) {
        //créer une liste de nom (String) à partir des éléments de maListeDePersonnes
        ArrayList<String> listeDeNomsDePersonnes= new ArrayList<String>();
        for(int i=0 ; i<maListeDePersonnes.getList().size() ; i++)
            listeDeNomsDePersonnes.add(((maListeDePersonnes.getPersonne(i)).getNom()));

        //adapter listeDeNomsDePersonnes à mon layout avec simple_spinner_item
        ArrayAdapter<String> dataAdapter =
                new ArrayAdapter<String>(   this,
                                            android.R.layout.simple_spinner_item,
                                            listeDeNomsDePersonnes);
        nomDeLaPersonneChoisie.setAdapter(dataAdapter);
    }

    /**
     * Ecouter lorsque le spinner change de valeur pour choisir une autre personne
     * @param nomDansSpinner personne qui a été choisie
     * @param photoDansImageView imageView de la personne
     * @param commentaireDansTextView textView de la personne
     */
    public void ecouteurSurSpinnerQuiChange(final Spinner nomDansSpinner,
                                            final ImageView photoDansImageView,
                                            final TextView commentaireDansTextView ) {
        nomDansSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                //retrouver la personneChoisie
                Personne laPersonneChoisie= maListeDePersonnes.getPersonne( nomDansSpinner.getSelectedItemPosition() );
                //changer l'image
                photoDansImageView.setImageResource(laPersonneChoisie.getPhoto());
                //changer le texte
                commentaireDansTextView.setText(laPersonneChoisie.getCommentaire());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(MainActivity.this, "Vous n'avez rien sélectionné", Toast.LENGTH_SHORT).show();

            }
        });
    }
}

